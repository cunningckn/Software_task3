#ifndef PID_H
#define PID_H
#include <algorithm>
class PID {
public:
    PID(float p, float i, float d, float maxI, float maxOutput);
    float calculate(float reference, float feedback);
    void clear();
private:
    float kp;
    float ki;
    float kd;
    float error;
    float lastError;
    float integral;
    float maxIntegral;
    float output;
    float maxOutput;
};

inline PID::PID(float p, float i, float d, float maxI, float maxOutput) {
    kp = p;
    ki = i;
    kd = d;
    maxIntegral = maxI;
    this->maxOutput = maxOutput;
    clear();
}

inline float PID::calculate(float reference, float feedback) {
    lastError = error;
    error = (reference - feedback) * 900 / 4000;

    output += error * kp;
    output += (error - lastError) * kd;

    int index = 0;
    if (error > 100 || error < -100) {
        index = 0;
    }
    else {
        index = 1;
        integral += error * ki;
    }

    output += index * integral;
    output = std::clamp(output, 0.0f, 890.0f);

    return output;
}

inline void PID::clear() {
    error = 0;
    lastError = 0;
    integral = 0;
    output = 0;
}
#endif
