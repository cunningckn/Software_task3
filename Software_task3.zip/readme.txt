嵌硬软件任务三：
本文件是C++工程文件夹，仅包含一个主文件：Software_task3.cpp

文件内定义了以下三个类，分别对应三种滤波算法
class MovingAverageFilter：	低通滤波器 (移动平均滤波)
class DifferentialFilter：	高通滤波器 (差分滤波)
class SimpleMovingAverage：	均值滤波器 (简单移动平均滤波)添加了选择排序算法滤去最高位和最低位

嵌硬组：陈凯宁